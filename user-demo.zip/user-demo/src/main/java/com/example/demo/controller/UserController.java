package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.service.UserService;

@RestController
@CrossOrigin(origins = {"http://localhost:4200","*"})
public class UserController {
	@Autowired
	private UserService us;
	
	@PostMapping("/user")
	public int addUser(@RequestBody User user)
	{
		return us.create(user);
	}
	
	@GetMapping("/user")
	public List<User> getAllUsers()
	{
		return us.read();
	}
	
	@GetMapping("/user/{username}/{password}")
	public User findUserByUserNamePassword(@PathVariable String username, @PathVariable String password)
	{
		return us.read(username, password);
	}
	
	@PutMapping("/user")
	public int modifyUser(@RequestBody User user)
	{
		return us.update(user);
	}

	@DeleteMapping("/user/{username}")
	public int removeUser(@PathVariable String username)
	{
		return us.delete(username);
	}

}
