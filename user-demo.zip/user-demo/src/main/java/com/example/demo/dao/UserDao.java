package com.example.demo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.demo.entity.User;

@Repository
public interface UserDao {

	int create(User user);

	List<User> read();

	User read(String username, String password);

	int update(User user);

	int delete(String username);

}