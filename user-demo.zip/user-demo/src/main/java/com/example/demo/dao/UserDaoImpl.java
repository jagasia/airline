package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.example.demo.entity.User;

@Component
public class UserDaoImpl implements UserDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int create(User user) {
		String sql="INSERT INTO USER_MASTER VALUES(?,?,?,?,?,?)";
		return jdbcTemplate.update(sql,user.getUsername(),user.getPassword(),user.getFirstName(),user.getLastName(),user.getEmail(),user.getPhone());
	}	
	@Override
	public List<User> read() {
		String sql="SELECT * FROM USER_MASTER";
		return jdbcTemplate.query(sql, new UserRowMapper());
	}
	@Override
	public User read(String username, String password) {
		String sql="SELECT * FROM USER_MASTER WHERE username=? AND password=?";
		return jdbcTemplate.queryForObject(sql, new UserRowMapper(),username, password);
	}	
	@Override
	public int update(User user) {
		String sql="UPDATE USER_MASTER SET password=?, firstName=?, lastName=?, email=?, phone=? WHERE username=?";
		return jdbcTemplate.update(sql,user.getPassword(),user.getFirstName(),user.getLastName(),user.getEmail(),user.getPhone(), user.getUsername());
	}
	@Override
	public int delete(String username) {
		String sql="DELETE FROM USER_MASTER WHERE username=?";
		return jdbcTemplate.update(sql,username);
	}
	
}
