package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.UserDao;
import com.example.demo.entity.User;

@Service
public class UserService {
	@Autowired
	private UserDao udao;
	
	public int create(User user)
	{
		return udao.create(user);
	}

	public List<User> read()
	{
		return udao.read();
	}

	public User read(String username, String password)
	{
		User user=null;
		user=udao.read(username, password);
		return user;
	}

	public int update(User user)
	{
		return udao.update(user);
	}

	public int delete(String username)
	{
		return udao.delete(username);
	}
}
